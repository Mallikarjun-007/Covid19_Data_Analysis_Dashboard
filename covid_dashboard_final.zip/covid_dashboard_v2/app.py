"""COVID-19 Data Analysis Dashboard v2 (Flask + Pandas + NumPy + Matplotlib)
Run:  python3 app.py   then open http://127.0.0.1:5000"""
import io, base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from flask import Flask, render_template_string, request, jsonify, Response

# ---------- Load and clean (same steps as Module 1) ----------
df = pd.read_csv("COVID_19_AMR_EMR_SEAR_Records.csv")
df["Date_reported"] = pd.to_datetime(df["Date_reported"])
cols = ["New_cases", "New_deaths"]
df[cols] = df[cols].clip(lower=0)
df["Year"] = df["Date_reported"].dt.year
OR, TE, NA, GR = "#F26A21", "#139A9A", "#0F1B3D", "#9CA3AF"
RC = {"AMR": OR, "EMR": TE, "SEAR": NA}
MET = {"New_cases": "New cases", "New_deaths": "New deaths"}
COUNTRIES = sorted(df["Country"].unique())
YEARS = [int(y) for y in sorted(df["Year"].unique())]
REGION_OF = df.drop_duplicates("Country").set_index("Country")["WHO_region"]
app = Flask(__name__)
short = lambda c: (c.replace("United States of America", "USA")
                    .replace(" (Islamic Republic of)", "")
                    .replace(" (Bolivarian Republic of)", ""))


def png():
    b = io.BytesIO()
    plt.tight_layout()
    plt.savefig(b, format="png", dpi=110)
    plt.close()
    return base64.b64encode(b.getvalue()).decode()


def filters():
    a = request.args
    region, country = a.get("region", "All"), a.get("country", "All")
    year, metric = a.get("year", "All"), a.get("metric", "New_cases")
    compare = a.get("compare", "None")
    if region not in ("All", "AMR", "EMR", "SEAR"): region = "All"
    if country not in COUNTRIES or (region != "All" and REGION_OF[country] != region):
        country = "All"
    if not (year.isdigit() and int(year) in YEARS): year = "All"
    if metric not in MET: metric = "New_cases"
    if compare not in COUNTRIES: compare = "None"
    return region, country, year, metric, compare


def subset(region, country, year):
    d = df
    if region != "All": d = d[d["WHO_region"] == region]
    if country != "All": d = d[d["Country"] == country]
    if year != "All": d = d[d["Year"] == int(year)]
    return d


def monthly(d, metric):
    return d.groupby("Date_reported")[metric].sum().resample("ME").sum()


@app.route("/")
def index():
    region, country, year, metric, compare = filters()
    d = subset(region, country, year)
    base = subset(region, country, "All")
    label = MET[metric]
    cum = d.groupby("Country").agg(cc=("Cumulative_cases", "max"), cd=("Cumulative_deaths", "max"),
                                   nc=("New_cases", "sum"), nd=("New_deaths", "sum"),
                                   r=("WHO_region", "first"))
    cases, deaths = cum["cc"].sum(), cum["cd"].sum()
    m = monthly(d, metric)
    kpi = [("Countries", f"{len(cum)}"), ("Cumulative cases", f"{cases/1e6:,.2f} M"),
           ("Cumulative deaths", f"{deaths/1e3:,.1f} K"),
           ("Case-fatality rate", f"{deaths/cases*100 if cases else 0:.2f} %"),
           (f"Peak month ({label.lower()})", m.idxmax().strftime("%b %Y"))]
    charts = []
    # 1. Trend over time (with optional comparison)
    plt.figure(figsize=(6, 4))
    name = country if country != "All" else (region if region != "All" else "All regions")
    plt.plot(m.index, m.values, color=OR, label=short(name))
    if compare != "None":
        mc = monthly(df[(df["Country"] == compare) & ((df["Year"] == int(year)) if year != "All" else True)], metric)
        plt.plot(mc.index, mc.values, color=NA, label=short(compare))
    plt.title(f"{label} per month", fontsize=10)
    plt.legend(frameon=False, fontsize=8)
    plt.grid(alpha=.3)
    charts.append(("Trend over time" + (" (comparison)" if compare != "None" else ""), png()))
    # 2. Distribution (pie)
    plt.figure(figsize=(6, 4))
    if region == "All" and country == "All":
        s = d.groupby("WHO_region")[metric].sum(); t = f"Share of {label.lower()} by WHO region"
    else:
        s = d.groupby("Country")[metric].sum().nlargest(5)
        s = pd.concat([s, pd.Series({"Others": d[metric].sum() - s.sum()})]); t = f"Share of {label.lower()}: top 5 + others"
    s = s[s > 0]
    plt.pie(s, labels=[short(i) for i in s.index], autopct="%1.1f%%", startangle=90,
            colors=[OR, TE, NA, "#8B5CF6", "#F59E0B", GR][:len(s)], textprops={"fontsize": 8})
    plt.title(t, fontsize=10)
    charts.append(("Distribution", png()))
    # 3. Top 10 countries
    plt.figure(figsize=(6, 4))
    top = d.groupby("Country")[metric].sum().nlargest(10)
    top.rename(short)[::-1].plot(kind="barh", color=OR)
    plt.title(f"Top 10 countries: {label.lower()}", fontsize=10); plt.ylabel("")
    charts.append(("Top 10 countries", png()))
    # 4. Per year
    plt.figure(figsize=(6, 4))
    (base.groupby("Year")[metric].sum() / 1e6).plot(kind="bar", color=TE, rot=0)
    plt.title(f"{label} per year (millions)", fontsize=10); plt.xlabel("")
    charts.append(("Per year", png()))
    # 5. Scatter cases vs deaths (log-log)
    plt.figure(figsize=(6, 4))
    sc = cum[(cum["cc"] > 0) & (cum["cd"] > 0)]
    for r, g in sc.groupby("r"):
        plt.scatter(g["cc"], g["cd"], color=RC[r], label=r, s=40, edgecolor="white", alpha=.9)
    for i, rr in sc.nlargest(3, "cc").iterrows():
        plt.annotate(short(i), (rr["cc"], rr["cd"]), fontsize=7, xytext=(4, 4), textcoords="offset points")
    plt.xscale("log"); plt.yscale("log")
    plt.xlabel("Cumulative cases (log)"); plt.ylabel("Cumulative deaths (log)")
    plt.title("Cumulative cases vs deaths", fontsize=10); plt.legend(frameon=False, fontsize=8); plt.grid(alpha=.3)
    charts.append(("Cases vs deaths (scatter)", png()))
    # 6. Histogram
    plt.figure(figsize=(6, 4))
    nz = d[d[metric] > 0][metric]
    plt.hist(np.log10(nz), bins=30, color=OR, edgecolor="white") if len(nz) else None
    plt.xlabel(f"log10({label.lower()})"); plt.ylabel("Records")
    plt.title(f"Distribution of {label.lower()} (log scale)", fontsize=10)
    charts.append(("Distribution (histogram)", png()))
    # 7. CFR by region (all regions, selected highlighted)
    plt.figure(figsize=(6, 4))
    ca = df.groupby("Country").agg(c=("Cumulative_cases", "max"), dd=("Cumulative_deaths", "max"), r=("WHO_region", "first"))
    rg = ca.groupby("r")[["c", "dd"]].sum(); cfr = rg["dd"] / rg["c"] * 100
    plt.bar(cfr.index, cfr.values, color=[RC[r] if region in ("All", r) else GR for r in cfr.index])
    for i, v in enumerate(cfr.values): plt.text(i, v + .02, f"{v:.2f}", ha="center", fontweight="bold")
    plt.title("Case-fatality rate by region (%)", fontsize=10)
    charts.append(("Case-fatality rate", png()))
    rows = [(short(i), r.r, f"{r.nc:,.0f}", f"{r.nd:,.0f}", f"{r.cc:,.0f}", f"{r.cd:,.0f}",
             f"{r.cd/r.cc*100:.2f}" if r.cc else "-") for i, r in cum.sort_values("cc", ascending=False).iterrows()]
    return render_template_string(PAGE, f=dict(region=region, country=country, year=year, metric=metric, compare=compare),
                                  kpi=kpi, charts=charts, rows=rows, n=len(d), countries=COUNTRIES, years=YEARS,
                                  met=MET, qs=request.query_string.decode())


@app.route("/download")
def download():
    d = subset(*filters()[:3])
    return Response(d.drop(columns="Year").to_csv(index=False), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=covid_filtered.csv"})


@app.route("/api/summary")
def api_summary():
    region, country, year, metric, _ = filters()
    d = subset(region, country, year)
    c = d.groupby("Country")[["Cumulative_cases", "Cumulative_deaths"]].max()
    return jsonify(filters=dict(region=region, country=country, year=year), records=len(d), countries=len(c),
                   cumulative_cases=int(c.iloc[:, 0].sum()), cumulative_deaths=int(c.iloc[:, 1].sum()))


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>COVID-19 Data Analysis Dashboard</title><style>
:root{--bg:#F5F7FB;--card:#fff;--ink:#1F2937;--mut:#5B6475;--line:#e5e7eb}
body.dark{--bg:#0B1220;--card:#162036;--ink:#E5E7EB;--mut:#9CA3AF;--line:#2B3856}
*{box-sizing:border-box}body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--ink)}
header{background:#0F1B3D;color:#fff;padding:16px 28px;border-bottom:4px solid #F26A21;display:flex;justify-content:space-between;align-items:center}
header h1{margin:0;font-size:23px}header p{margin:4px 0 0;color:#B9C6E4;font-size:13px}
button,.btn{background:#F26A21;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:14px;cursor:pointer;text-decoration:none;display:inline-block}
.ghost{background:transparent;border:1px solid #cbd5e1;color:var(--ink)}
main{max-width:1200px;margin:0 auto;padding:20px}
form{display:flex;flex-wrap:wrap;gap:12px;align-items:end;background:var(--card);padding:14px 16px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.08);margin-bottom:18px}
label{font-size:12px;color:var(--mut);display:block;margin-bottom:3px}
select,input{padding:7px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;background:var(--card);color:var(--ink)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin-bottom:18px}
.kpi,.card{background:var(--card);border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.08);padding:14px 16px}
.kpi small{color:var(--mut);font-size:12px}.kpi b{display:block;font-size:23px;color:#F26A21;margin-top:4px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:16px}
.card h3{margin:0 0 8px;font-size:15px}.card img{width:100%;background:#fff;border-radius:6px}
.tw{max-height:380px;overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}
th{background:#0F1B3D;color:#fff;padding:8px;cursor:pointer;position:sticky;top:0;text-align:right}
td{padding:6px 8px;text-align:right;border-bottom:1px solid var(--line)}th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}
footer{text-align:center;color:var(--mut);font-size:12px;padding:20px}
</style></head><body>
<header><div><h1>COVID-19 Data Analysis Dashboard</h1><p>WHO data for AMR, EMR and SEAR &middot; Python, Pandas, NumPy, Matplotlib &middot; Aditya University</p></div>
<button class="ghost" style="color:#fff;border-color:#8899bb" onclick="tg()">Dark / Light</button></header>
<main><form method="get" id="fm">
<div><label>WHO region</label><select name="region" onchange="fm.submit()">{% for r in ["All","AMR","EMR","SEAR"] %}<option {{ "selected" if r==f.region }}>{{ r }}</option>{% endfor %}</select></div>
<div><label>Country</label><select name="country" onchange="fm.submit()"><option>All</option>{% for c in countries %}<option {{ "selected" if c==f.country }}>{{ c }}</option>{% endfor %}</select></div>
<div><label>Year</label><select name="year" onchange="fm.submit()"><option>All</option>{% for y in years %}<option {{ "selected" if y|string==f.year }}>{{ y }}</option>{% endfor %}</select></div>
<div><label>Measure</label><select name="metric" onchange="fm.submit()">{% for k,v in met.items() %}<option value="{{ k }}" {{ "selected" if k==f.metric }}>{{ v }}</option>{% endfor %}</select></div>
<div><label>Compare with (trend chart)</label><select name="compare" onchange="fm.submit()"><option value="None">None</option>{% for c in countries %}<option {{ "selected" if c==f.compare }}>{{ c }}</option>{% endfor %}</select></div>
<div><a class="btn ghost" href="/">Reset</a> <a class="btn" href="/download?{{ qs }}">Download CSV</a></div>
<span style="color:var(--mut);font-size:13px">{{ n }} records analysed</span></form>
<div class="kpis">{% for k,v in kpi %}<div class="kpi"><small>{{ k }}</small><b>{{ v }}</b></div>{% endfor %}</div>
<div class="grid">{% for t,c in charts %}<div class="card"><h3>{{ t }}</h3><img alt="{{ t }}" src="data:image/png;base64,{{ c }}"></div>{% endfor %}
<div class="card" style="grid-column:1/-1"><h3>Country table <input id="q" placeholder="Search country..." oninput="ft()" style="float:right"></h3>
<div class="tw"><table id="tb"><tr><th onclick="st(0)">Country</th><th onclick="st(1)">Region</th><th onclick="st(2)">New cases</th><th onclick="st(3)">New deaths</th><th onclick="st(4)">Cum. cases</th><th onclick="st(5)">Cum. deaths</th><th onclick="st(6)">CFR %</th></tr>
{% for r in rows %}<tr>{% for x in r %}<td>{{ x }}</td>{% endfor %}</tr>{% endfor %}</table></div></div></div></main>
<footer>M.Mallikarjun &middot; T.Gayathri &middot; CH.Pavan &middot; Visalakshi &middot; Guide: Dr. Tirukoti Sudha Rani</footer>
<script>
try{if(localStorage.getItem("dk")=="1")document.body.classList.add("dark")}catch(e){}
function tg(){document.body.classList.toggle("dark");try{localStorage.setItem("dk",document.body.classList.contains("dark")?"1":"0")}catch(e){}}
function ft(){var q=document.getElementById("q").value.toLowerCase();document.querySelectorAll("#tb tr:not(:first-child)").forEach(function(r){r.style.display=r.cells[0].innerText.toLowerCase().indexOf(q)>-1?"":"none"})}
var dir={};function st(n){var t=document.getElementById("tb"),rs=Array.from(t.rows).slice(1);dir[n]=!dir[n];
rs.sort(function(a,b){var x=a.cells[n].innerText.replace(/,/g,""),y=b.cells[n].innerText.replace(/,/g,"");var nx=parseFloat(x),ny=parseFloat(y);
var c=(isNaN(nx)||isNaN(ny))?x.localeCompare(y):nx-ny;return dir[n]?c:-c});rs.forEach(function(r){t.appendChild(r)})}
</script></body></html>"""

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
